﻿namespace WebBlog6.Models.db
{
    public class TegBlog
    {
        public int Id { get; set; }
        public int BId { get; set; }
        public string TId { get; set; }
    }
}
